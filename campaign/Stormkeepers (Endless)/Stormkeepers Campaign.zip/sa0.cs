## -------------------------------------------------------------------- Header
//  Filename:   SA0.cs
//  AUTHOR:     ^TFW^ Wilzuun
//  NOTES:      This is the first Mission to the Order of the Stormkeepers campaign.

## -------------------------------------------------------------------- Install Instructions
// The the entirety of the folder this file is in (even the directory) and place it in your Starsiege
// install directory under C:/Path/To/Starsiege/Campaign

## -------------------------------------------------------------------- IMPORTANT NOTES
// There are no important notes as of yet.

## -------------------------------------------------------------------- Version History
// 1.0 - 14th Feb 2021
//      Started project.
## -------------------------------------------------------------------- Required Files.
exec(otskCampaignData);
exec(otskCampaignFunctions);

## -------------------------------------------------------------------- Mission Brief
MissionBriefInfo missionData
{
   title                = "New Stormkeeper Recruitment Processing";
   planet               = *IDSTR_PLANET_MARS;
   campaign             = "Cybrid Counteraction";
   dateOnMissionEnd     = 28281000;
   shortDesc            = "Recruitment Qualification Test";
   longDescRichText     = "You've applied to, and have been accepted into Order " 
                          @ "of the Stormkeepers. Let recap what our Order does. "
                          @ "We're a group concerned with preparing for the invasion "
                          @ "of the Cybrid forces. We want to make sure that we're "
                          @ "as prepped for that as we can possibly be. We salvage "
                          @ "wreckage sites of Martian Rebellion battle sites. We "
                          @ "do have the chance of the Rebels or the Imperial Police "
                          @ "mistaking our operations as an enemy of theirs, this "
                          @ "is sadly more common that we'd like to openly admit. "
                          @ "We do try to stay nuetral in the conflicts of the two, "
                          @ "staying out of their way if they are fighting each other, "
                          @ "and trying to clean up some of the mess to help us prepare."
                          @ "Your first mission is just a training mission, were we guage "
                          @ "your ability to pilot a vehicle, and following orders. "
                          @ "So without further delay, lets get your test going, shall we?"
                          @ ""
                          ;
   nextMission          = "sa1";
   successDescRichText  = "Congratulations on passing your qualification test. You "
                          @ "are hereby a trial run member of the Stormkeepers. The "
                          @ "more successes you have doing your missions, the higher "
                          @ "your rank will become, and the more equipement you will "
                          @ "get access to. We're looking forward to promising results "
                          @ "from you. That test can be exhausting to some, so how "
                          @ "about you go get some rest. Your first mission is day "
                          @ "after tomorrow."
                          @ ""
                          ;
   failDescRichText     = "Considering you failed the qualifications test, we're "
                          @ "going to ask that you go home and practice a fair bit "
                          @ "more before applying to join our ranks again. Thank you "
                          @ "for your interest."
                          @ ""
                          ;
   location             = *IDSTR_HA0_LOCATION;
};

## -------------------------------------------------------------------- Mission Objectives
MissionBriefObjective missionObjective1
{
	isPrimary 	= true;
	status 		= *IDSTR_OBJ_ACTIVE;
	shortTxt	= "Conbat Training";
	longTxt		= "Defeat the Combat Instructor. We're not looking to kill him, "
                  @ "that isn't the aim to this test. ";
};

MissionBriefObjective missionObjective2
{
	isPrimary 	= true;
	status 		= *IDSTR_OBJ_ACTIVE;
	shortTxt	= "Convoy Test";
	longTxt		= "Protect the convoy as it gets to base. This specific run normally goes smoothly, rarely ever an attack on this route. But all things, consider this your first official mission.";
};

## -------------------------------------------------------------------- onMission
function onMissionStart()
{
    dbecho(3, "TRIGGER: onMissionStart();");
    cdAudioCycle(ss3, cyberntx, ss4);
}

## -------------------------------------------------------------------- Player
function player::onAdd( %this )
{
    dbecho(3, "TRIGGER: player::onAdd(" @ %this @ ");");
    // Setting this lets us do a player check easily where ever we need it without
    // needed to convert a vehicle ID to a player number.
	$ThePlayer = %this;
}

## -------------------------------------------------------------------- Vehicle
function Trainer::vehicle::onAttacked(%this, %that)
{
    dbecho(3, "Trainer::vehicle::onAttacked(" @ %this @ ", "@ %that @ ");");
    healObject(%this,5000);
    if (%that == $playerNum.id) 
    {
        $TrainerAttacks++;
        if($TrainerAttacks == 10)
        {
            order(%this, shutdown, true);
            missionObjective1.status = *IDSTR_OBJ_COMPLETED;
            say(%$playerNum, 0, "We're done. That convoy test is about to begin, get to your next nav point.");
            // activate next NavPoint
        }
    }
}

function Ambush::vehicle::onDestroyed(%this, %that)
{
    dbecho(3, "Ambush::vehicle::onDestroyed(" @ %this @ ", "@ %that @ ");");
    missionObjective2.status = *IDSTR_OBJ_COMPLETED;
    // activate next NavPoint
}

function vehicle::onAdd(%this)
{
    dbecho(3, "TRIGGER: vehicle::onAdd(" @ %this @ ");");
    if(%this == playerManager::PlayerNumToVehicleId($playerNum))
        $playerNum.id = %this;
}

## -------------------------------------------------------------------- Structure

## -------------------------------------------------------------------- Trigger
function StorkeeperBase::trigger::onEnter(%this, %that)
{
    dbecho(3, "StorkeeperBase::trigger::onEnter(" @ %this @ ", "@ %that @ ");");
    if (missionObjective2.status == *IDSTR_OBJ_COMPLETED && missionObjective1.status == *IDSTR_OBJ_COMPLETED)
    {
        win();
    }
}

## -------------------------------------------------------------------- Server

## -------------------------------------------------------------------- Custom Fn
