$otsk::salvageLocationX = 0;
$otsk::salvageLocationY = 0;
$otsk::missionsCompleted = 0;
$otsk::rank = 1;
$otsk::missionsPerRank = 5;